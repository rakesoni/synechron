package com.example.bankapi.controller;

import com.example.bankapi.model.Account;
import com.example.bankapi.model.TransferRequest;
import com.example.bankapi.service.AccountService;
import org.springframework.web.bind.annotation.*;

import java.util.Collection;

@RestController
public class AccountController {

    private final AccountService accountService;

    public AccountController(AccountService accountService) {
        this.accountService = accountService;
    }

    @GetMapping("/")
    public String home() {
        return "Simple Bank Transfer API Running";
    }

    @GetMapping("/accounts")
    public Collection<Account> getAccounts() {
        return accountService.getAllAccounts();
    }

    @GetMapping("/accounts/{id}")
    public Account getAccount(@PathVariable int id) {
        return accountService.getAccount(id);
    }

    @PostMapping("/transfer")
    public String transfer(@RequestBody TransferRequest request) {
        return accountService.transfer(request);
    }
}